This folder contains message handlers for the xPLGirder plugin.

The file extension must be .lua to enable them. Some are enabled 
by default, others disabled (.txt extension). Just modify them 
as it suits your needs.

A template for creating new handlers is also included.